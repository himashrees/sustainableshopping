//package com.example.RootandRise.controller;
//
//import com.example.RootandRise.model.Product;
//import com.example.RootandRise.service.ScraperService;
//import com.example.RootandRise.repository.ProductRepository; // assuming you have a repository for Product
//
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//@CrossOrigin("*")
//@RequestMapping("/api/products")
//public class ProductController {
//
//    private final ScraperService scraperService;
//    private final ProductRepository productRepository; // Assuming you have this repository
//
//    public ProductController(ScraperService scraperService, ProductRepository productRepository) {
//        this.scraperService = scraperService;
//        this.productRepository = productRepository;
//    }
//
//    @GetMapping("/scrape")
//    public List<Product> scrapeProducts(@RequestParam String query) {
//        List<Product> products = new ArrayList<>();
//
//        // Scraping from Snapdeal
////        products.addAll(scraperService.scrapeSnapdeal(query));
//
//        // Scraping from Meesho
//        products.addAll(scraperService.scrapeMeesho(query));
////
////        // Scraping from Ajio
////        products.addAll(scraperService.scrapeAjio(query));
////
////        // Scraping from Myntra
////        products.addAll(scraperService.scrapeMyntra(query));
//
//        // Save the products to the database if needed
//        productRepository.saveAll(products);
//
//        return products;
//    }
//
//
//    @GetMapping("/all")
//    public List<Product> getAllProducts() {
//        return productRepository.findAll(); // Fetch all products saved in database
//    }
//}

package com.example.RootandRise.controller;

import com.example.RootandRise.model.Product;
import com.example.RootandRise.repository.ProductRepository;
import com.example.RootandRise.service.ScraperService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/products")
public class ProductController {

    private final ScraperService scraperService;
    private final ProductRepository productRepository;

    public ProductController(ScraperService scraperService, ProductRepository productRepository) {
        this.scraperService = scraperService;
        this.productRepository = productRepository;
    }

    @GetMapping("/scrape-eco-friendly")
    public List<Product> scrapeEcoFriendlyProducts(@RequestParam String query) {
        // Encode query for eco-friendly products
        String searchQuery = query.replace(" ", "%20");
        String apiUrl = "https://api.zenrows.com/v1/?apikey=7823abf7d0585425e11ec0328c3281e6164f16d9&url=https://www.meesho.com/search?q=" + searchQuery;

        // Fetch and parse data, then save it to the database
        List<Product> products = scraperService.fetchAndStoreProducts(apiUrl);
        productRepository.saveAll(products);
        return products;
    }

    @GetMapping("/all")
    public List<Product> getAllProducts() {
        return productRepository.findAll(); // Fetch all products saved in the database
    }
}

