package com.example.RootandRise.controller;



import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.RootandRise.model.User;
import com.example.RootandRise.repository.*;
//import com.example.RootandRise.service.EmailExistsResponse;
import com.example.RootandRise.service.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserService userService;
    
    @PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User user, HttpSession session) {
        User storedUser = userRepository.findByEmail(user.getEmail());
        if (storedUser != null && user.getPassword().equals(storedUser.getPassword())) {
            session.setAttribute("email", storedUser.getEmail());
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }
	
	@PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        User storedUser = userRepository.findByEmail(user.getEmail());
        if (storedUser != null) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } else {
        	userRepository.save(user);
            return new ResponseEntity<>(HttpStatus.CREATED);
        }
    }
	

	   

	    public UserController(UserRepository userRepository) {
	        this.userRepository = userRepository;
	    }

//	    @GetMapping("/check-email/{email}")
//	    public ResponseEntity<EmailExistsResponse> checkEmailExists(@PathVariable String email) {
//	        boolean exists = userService.existsByEmail(email);
//	        EmailExistsResponse emailExistsResponse = new EmailExistsResponse(exists);
//	        return ResponseEntity.ok(emailExistsResponse);
//	    }

	    
        @PostMapping("/forgotPassword")
	    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
	        String email = request.get("email");
	        String newPassword = request.get("newPassword");
	        
	        User user = userRepository.findByEmail(email);
	        if (user == null) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No user found with the given email address");
	        }
	        user.setPassword(newPassword);
	        userRepository.save(user);
	        
	        return ResponseEntity.ok("Password reset successful");
	    }
        
        
//   


}

