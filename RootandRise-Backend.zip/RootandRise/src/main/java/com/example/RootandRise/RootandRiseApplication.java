package com.example.RootandRise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RootandRiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(RootandRiseApplication.class, args);
	}

}
