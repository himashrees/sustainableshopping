package com.example.RootandRise.service;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Scraper {
    public static void main(String[] args) throws Exception {
        String url = "https://www.amazon.in/s?k=eco-friendly+products";
        Document doc = Jsoup.connect(url).get();

        for (Element product : doc.select(".s-title-instructions-style")) {
            String title = product.text();
            String link = product.attr("href");
            System.out.println("Title: " + title);
            System.out.println("Link: " + "https://www.amazon.in" + link);
        }
    }
}


