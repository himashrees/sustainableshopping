package com.example.RootandRise.controller;



import com.example.RootandRise.model.Product;
import com.example.RootandRise.model.UserPreferences;
import com.example.RootandRise.service.ExternalApiService;
import com.example.RootandRise.service.RootAndRiseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class RootAndRiseController {

    private final RootAndRiseService rootAndRiseService;
    private final ExternalApiService externalApiService;

    // Constructor-based dependency injection for both services
    public RootAndRiseController(RootAndRiseService rootAndRiseService, ExternalApiService externalApiService) {
        this.rootAndRiseService = rootAndRiseService;
        this.externalApiService = externalApiService;
    }

    @PostMapping("/preferences")
    public ResponseEntity<UserPreferences> savePreferences(@RequestBody UserPreferences preferences) {
        return ResponseEntity.ok(rootAndRiseService.savePreferences(preferences));
    }

    @GetMapping("/external-products")
    public ResponseEntity<List<Product>> getExternalProducts(@RequestParam String searchQuery) {
        // Call fetchProducts on the injected externalApiService instance
        List<Product> products = externalApiService.fetchProducts(searchQuery);
        return ResponseEntity.ok(products);
    }

    @GetMapping("/recommendations")
    public ResponseEntity<List<Product>> getRecommendations(@RequestParam String category) {
        return ResponseEntity.ok(rootAndRiseService.getRecommendations(category));
    }
}
