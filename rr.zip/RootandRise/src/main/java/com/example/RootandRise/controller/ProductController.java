package com.example.RootandRise.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.RootandRise.service.ScraperService;
import com.example.RootandRise.model.Product;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ScraperService scraperService;

    public ProductController(ScraperService scraperService) {
        this.scraperService = scraperService;
    }

    @GetMapping("/scrape")
    public List<Product> scrapeProducts(@RequestParam String query) {
        return scraperService.scrapeAmazon(query);
    }
}
