package com.example.RootandRise.service;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import com.example.RootandRise.model.Product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ScraperService {

    public List<Product> scrapeAmazon(String searchQuery) {
        List<Product> products = new ArrayList<>();
        String baseUrl = "https://www.amazon.in/s?k=" + searchQuery.replace(" ", "+");

        try {
            Document doc = Jsoup.connect(baseUrl)
                    .userAgent("Mozilla/5.0")
                    .timeout(10000)
                    .get();

            Elements productElements = doc.select(".s-main-slot .s-result-item");
            for (Element productElement : productElements) {
                Element linkElement = productElement.selectFirst(".a-link-normal.s-link-style");
                if (linkElement != null) {
                    String title = linkElement.text();
                    String link = "https://www.amazon.in" + linkElement.attr("href");

                    // Ensure the purchase link is within the length limit
                    String purchaseLink = link;
                  

                    Product product = new Product();
                    product.setName(title);
                    product.setPurchaseLink(purchaseLink);  // Set the truncated purchase link
                    products.add(product);
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Better to use proper logging
        }

        return products;
    }

    // Add similar methods for other websites
}
